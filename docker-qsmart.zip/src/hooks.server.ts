// src/hooks.server.ts
// Injecte la session Supabase dans locals à chaque requête.
// Permet aux +layout.server.ts et +page.server.ts de lire locals.session.

import { createClient } from '@supabase/supabase-js';
import type { Handle } from '@sveltejs/kit';
import {
  PUBLIC_SUPABASE_URL,
  PUBLIC_SUPABASE_ANON_KEY
} from '$env/static/public';

export const handle: Handle = async ({ event, resolve }) => {
  const supabase = createClient(PUBLIC_SUPABASE_URL, PUBLIC_SUPABASE_ANON_KEY);

  // Récupérer le token depuis le cookie de session
  const accessToken = event.cookies.get('sb-access-token');
  const refreshToken = event.cookies.get('sb-refresh-token');

  if (accessToken && refreshToken) {
    await supabase.auth.setSession({
      access_token: accessToken,
      refresh_token: refreshToken
    });
  }

  const { data: { session } } = await supabase.auth.getSession();
  event.locals.session = session;

  return resolve(event);
};
