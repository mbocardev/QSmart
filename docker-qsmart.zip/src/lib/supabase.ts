// src/lib/supabase.ts
// Client Supabase partagé — utilisé côté client ET dans les hooks server-side

import { createClient } from '@supabase/supabase-js';
import {
  PUBLIC_SUPABASE_URL,
  PUBLIC_SUPABASE_ANON_KEY
} from '$env/static/public';

export const supabase = createClient(PUBLIC_SUPABASE_URL, PUBLIC_SUPABASE_ANON_KEY, {
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

// Types dérivés du schéma
export type StatutFile = 'OUVERTE' | 'PAUSE' | 'FERMEE';
export type StatutTicket = 'EN_ATTENTE' | 'APPELE' | 'TRAITE' | 'ABSENT';

export interface Commerce {
  id: string;
  nom: string;
  slug: string;
  statut_file: StatutFile;
  dernier_ticket_appele: number;
  owner_id: string;
  created_at: string;
}

export interface Ticket {
  id: string;
  commerce_id: string;
  numero_ordre: number;
  statut: StatutTicket;
  nom_client: string | null;
  push_sub: string | null;
  cree_a: string;
  appele_a: string | null;
}

export interface PushSubscription {
  id: string;
  ticket_id: string;
  endpoint: string;
  p256dh: string;
  auth_key: string;
}
